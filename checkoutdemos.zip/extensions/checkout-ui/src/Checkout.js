import {
  reactExtension,
  Banner,
  BlockStack,
  Text,
  useAppMetafields,
  useApi,
  useMetafields,
  useCartLines,
  useTotalAmount,
  Checkbox,
  useApplyAttributeChange,
  useAttributes,
  usePurchasingCompany,
  useApplyMetafieldsChange
} from "@shopify/ui-extensions-react/checkout";

export default reactExtension("purchase.checkout.block.render", () => (
  <Extension />
));

function Extension() {
  const { buyerIdentity } = useApi();
  const appMetafields = useAppMetafields();
  const totalAmount = useTotalAmount();
  const applyAttributeChange = useApplyAttributeChange();
  const attributes = useAttributes();
  const ab = usePurchasingCompany()
  // console.log("ab", attributes)
  // Get credit from app metafield or fallback
  const companyCreditValue =
    appMetafields && appMetafields.length > 0 && appMetafields[0]?.metafield?.value
    && appMetafields[0].metafield.value;
  const currentCredit = parseFloat(companyCreditValue) || 0;
  // console.log("appMetafields full object:", JSON.stringify(appMetafields, null, 2));


  // Get company details
  const rawCompanyId = buyerIdentity?.purchasingCompany?.current?.company?.id;
  const companyId = rawCompanyId?.match(/Company\/(\d+)/)?.[1];
  const companyName = buyerIdentity?.purchasingCompany?.current?.company?.name ?? "Company";
  // console.log("appMetafields object:", JSON.stringify(buyerIdentity, null, 2));

  // Calculate order & credit
  const orderTotal = parseFloat(totalAmount?.amount || 0);
  const remainingCredit = Math.max(currentCredit - orderTotal, 0);
  const creditCoversFullOrder = currentCredit >= orderTotal;
  const creditCoversPartialOrder = currentCredit > 0 && currentCredit < orderTotal;
  const remainingPaymentNeeded = Math.max(orderTotal - currentCredit, 0);
  // console.log(currentCredit, "remainingCredit", remainingCredit)

  // console.log(currentCredit)
  const handleStoreCreditChange = async (isChecked) => {
    try {
      if (isChecked) {
        await applyAttributeChange({ key: "use_store_credit", type: "updateAttribute", value: "true" });
        await applyAttributeChange({ key: "store_credit_amount", type: "updateAttribute", value: currentCredit.toString() });
        await applyAttributeChange({ key: "order_total", type: "updateAttribute", value: orderTotal.toString() });
        await applyAttributeChange({ key: "remain_credit", type: "updateAttribute", value: remainingCredit.toString() });
      } else {
        await applyAttributeChange({ key: "use_store_credit", type: "updateAttribute", value: "false" });
        await applyAttributeChange({ key: "store_credit_amount", type: "updateAttribute", value: currentCredit.toString() });
        await applyAttributeChange({ key: "order_total", type: "updateAttribute", value: orderTotal.toString() });
        await applyAttributeChange({ key: "remain_credit", type: "updateAttribute", value: currentCredit.toString() });
      }

      console.log("end")
    } catch (error) {
      console.error("Error applying store credit attributes:", error);
    }
  };


  return (
    <BlockStack padding="tight">
      <Banner title="Company Store Credit" status="info">
        {currentCredit > 0 && currentCredit != "" ? (
          <>
            <Text>Available company credit for {companyName}: ₹{currentCredit}</Text>
            {orderTotal > 0 && <Text> Order Total: ₹{orderTotal}</Text>}

            {creditCoversFullOrder ? (
              <>
                <Text>✅ Credit covers full order! No payment needed.</Text>
                <Text> Remaining Credit: ₹{remainingCredit}</Text>
              </>
            ) : creditCoversPartialOrder ? (
              <>
                <Text>💰 Partial credit available! Use ₹{currentCredit} from credit</Text>
                <Text> Remaining Payment: ₹{remainingCredit}</Text>
              </>
            ) : (
              <Text>❌ Insufficient Credit</Text>
            )}

            <Checkbox
              onChange={handleStoreCreditChange}
              name="use_store_credit"
              checked={attributes?.find(attr => attr.key === 'use_store_credit')?.value === 'true'}
            >
              {creditCoversFullOrder
                ? `Apply Store Credit (₹${orderTotal})`
                : `Apply Partial Store Credit (₹${currentCredit}) - Pay ₹${remainingPaymentNeeded}`}
            </Checkbox>
          </>
        ) : (
          <Text>No company credit available</Text>
        )}
      </Banner>
    </BlockStack>
  );
}
