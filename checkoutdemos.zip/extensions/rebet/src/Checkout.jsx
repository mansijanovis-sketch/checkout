import {
  reactExtension,
  Banner,
  BlockStack,
  Checkbox,
  Text,
  useApi,
  useApplyAttributeChange,
  useInstructions,
  useTranslate,
  useCustomer,
} from "@shopify/ui-extensions-react/checkout";
import { useEffect } from "react";

export default reactExtension("purchase.checkout.block.render", () => (
  <Extension />
));

function Extension() {
  const translate = useTranslate();
  const { extension } = useApi();
  const instructions = useInstructions();
  const applyAttributeChange = useApplyAttributeChange();
  const customer = useCustomer();

  const API_URL = "https://47d0a9935d7a.ngrok-free.app/api/orders";

  useEffect(() => {
    if (!customer?.id) return;

    fetch(`${API_URL}?customerId=${encodeURIComponent(customer.id)}`)
      .then(async (res) => {
        const data = await res.json();
        console.log("Orders JSON:", data);
      })
      .catch((err) => console.error("Error fetching orders:", err));
  }, [customer?.id]);

  if (!instructions.attributes.canUpdateAttributes) {
    return (
      <Banner title="Rebet" status="warning">
        {translate("attributeChangesAreNotSupported")}
      </Banner>
    );
  }

  async function onCheckboxChange(isChecked) {
    const result = await applyAttributeChange({
      key: "requestedFreeGift",
      type: "updateAttribute",
      value: isChecked ? "yes" : "no",
    });
    console.log("applyAttributeChange result", result);
  }

  return (
    <BlockStack border="dotted" padding="tight">
      <Banner title="Rebet">
        {translate("welcome", {
          target: (
            <Text emphasis="italic">
              {extension.target} {customer?.id || "No customer"}
            </Text>
          ),
        })}
      </Banner>
      <Checkbox onChange={onCheckboxChange}>
        {translate("iWouldLikeAFreeGiftWithMyOrder")}
      </Checkbox>
    </BlockStack>
  );
}
