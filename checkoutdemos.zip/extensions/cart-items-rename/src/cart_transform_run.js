// No @ts-check and no typedefs — pure JavaScript

const NO_CHANGES = {
  operations: [],
};

export function cartTransformRun(input) {
  const useStoreCredit = input.cart.useStoreCredit?.value === "true";
  const storeCreditAmount = input.cart.storeCreditAmount?.value;
  const orderAmount = input.cart.orderAmount?.value;
  const remain = input.cart.remainCredit?.value;

  console.log("useStoreCredit",useStoreCredit)

  if (useStoreCredit) {

    const operations = input.cart.lines
      .filter(
        (line) =>
          line.merchandise.__typename === "ProductVariant" 
      )
      .map((line) => ({
        lineUpdate: {
          cartLineId: line.id,
          title: line.merchandise.product.title,
          price: {
            adjustment: {
              fixedPricePerUnit: {
                amount: "0.00", // store currency used automatically
              },
            },
          },
        },
      }));
console.log(operations)
    return { operations }; // ✅ return object, not array
  } else {
    return NO_CHANGES;
  }
}
